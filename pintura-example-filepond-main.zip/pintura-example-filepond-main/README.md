# Pintura FilePond example project

Install `@pqina/pintura`, `@pqina/filepond-plugin-image-editor`, `filepond`, `filepond-plugin-file-poster`, and a local node server by running `npm install`, then run `npm start` to start the server on localhost.

Or try it out right now and [open the project on StackBlitz](https://stackblitz.com/github/pqina/pintura-example-filepond?file=index.html)

### License

This projects uses a test version of Pintura. This version of Pintura will show a watermark in the editor and on generated images.

Purchase a license at https://pqina.nl/pintura to use Pintura in production.
